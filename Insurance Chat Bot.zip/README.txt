Set up Python environment, then install 2 below packages
pip install nltk
pip install streamlit

running app from terminal
streamlit run main.py